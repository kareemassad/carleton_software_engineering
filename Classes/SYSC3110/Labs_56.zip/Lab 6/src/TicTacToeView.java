public interface TicTacToeView {
    void handleTicTacToeStatusUpdate(TicTacToeModel ticTacToeModel, TicTacToeModel.Status status, int x, int y);
}
