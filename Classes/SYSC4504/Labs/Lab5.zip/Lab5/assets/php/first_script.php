<?php
    echo "<h1>My First PHP Script</h1>";
    echo "<p>Today is " .date("Y/m/d"). "</p>";
?>