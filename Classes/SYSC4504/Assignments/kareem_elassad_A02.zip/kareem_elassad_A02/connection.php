<?php
    $server_name = 'localhost';
    $database_name = 'kareem_elassad_lab05';
    $username = 'root';
    $password = '';
?>